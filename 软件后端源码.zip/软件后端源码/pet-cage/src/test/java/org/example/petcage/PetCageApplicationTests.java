package org.example.petcage;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PetCageApplicationTests {

    @Test
    void contextLoads() {
    }

}
