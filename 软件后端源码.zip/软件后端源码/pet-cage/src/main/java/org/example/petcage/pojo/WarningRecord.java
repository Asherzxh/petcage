package org.example.petcage.pojo;

import lombok.Data;
import java.time.LocalDateTime;

@Data
public class WarningRecord {
    private Integer id;              // 主键
    private Integer petId;           // 宠物ID
    private String warningType;      // 预警类型
    private LocalDateTime warningTime;// 预警时间
    private Integer isHandle;        // 0未处理 1已处理
}