package org.example.petcage.pojo;

import lombok.Data;
import java.time.LocalDateTime;

@Data
public class PetHealth {
    private Integer id;              // 主键
    private Integer petId;           // 宠物ID
    private Integer heartRate;       // 心率
    private Float bloodOxygen;       // 血氧
    private Float bodyTemperature;   // 体温
    private LocalDateTime createTime;// 采集时间
}