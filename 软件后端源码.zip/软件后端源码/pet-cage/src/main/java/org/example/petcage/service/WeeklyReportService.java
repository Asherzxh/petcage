package org.example.petcage.service;

public interface WeeklyReportService {
    void initializeReport(String id);

    Object getReport(Integer petId, Integer type);
}
