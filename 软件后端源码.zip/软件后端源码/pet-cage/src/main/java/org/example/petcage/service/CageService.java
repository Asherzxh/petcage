package org.example.petcage.service;

import org.example.petcage.pojo.CageControl;
import org.example.petcage.pojo.CageEnv;

public interface CageService{
    CageEnv getCageStatus();

    CageControl getCageControlStatus();

    void updateCageControlStatus(CageControl cageControl);

    void insertCageStatus(CageEnv cageEnv);

    void autoResetControlStatus(CageControl delayControl, int i);
}
