package org.example.petcage.service;

import org.example.petcage.pojo.FeedRecord;

public interface FeedRecordService {
    void insertFeedRecord(FeedRecord feedRecord);
}
