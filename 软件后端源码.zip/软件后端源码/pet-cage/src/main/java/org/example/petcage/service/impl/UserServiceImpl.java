package org.example.petcage.service.impl;

import org.example.petcage.DTO.UserLoginDTO;
import org.example.petcage.enumeration.WarningTypeEnum;
import org.example.petcage.exception.BusinessException;
import org.example.petcage.mapper.UserMapper;
import org.example.petcage.pojo.User;
import org.example.petcage.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class UserServiceImpl implements UserService {
    @Autowired
    private UserMapper userMapper;
    @Override
    public User login(UserLoginDTO dto) {
        User user = userMapper.getByUserName(dto.getUsername());
        if (user == null) {
            throw new BusinessException(WarningTypeEnum.USER_NOT_EXIST.getWarningType());
        }
        if (!dto.getPassword().equals(user.getPassword())) {
            //密码错误
            throw new BusinessException(WarningTypeEnum.USER_PASSWORD_WRONG.getWarningType());
        }

        return user;
    }

    @Override
    public User getUserById(String id) {
        User user = userMapper.getUserById(id);
        user.setPassword("*******");
        return user;
    }
}
