package org.example.petcage.controller;

import org.example.petcage.config.BaseContext;
import org.example.petcage.pojo.CageControl;
import org.example.petcage.pojo.CageEnv;
import org.example.petcage.pojo.FeedRecord;
import org.example.petcage.pojo.WaterRecord;
import org.example.petcage.result.Result;
import org.example.petcage.service.CageService;
import org.example.petcage.service.FeedRecordService;
import org.example.petcage.service.WaterRecordService;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@RestController
public class CageController {
    @Autowired
    CageService cageService;
    @Autowired
    FeedRecordService feedRecordService;
    @Autowired
    WaterRecordService waterRecordService;
    @GetMapping("/cage/status")
    public Result getCageStatus(){
        CageEnv cageStatus = cageService.getCageStatus();
        return Result.success(cageStatus);
    }
    @GetMapping("/cage/control/status")
    public Result getCageControlStatus(){
        CageControl cageControl = cageService.getCageControlStatus();
        return Result.success(cageControl);
    }

    @PutMapping("/cage/control/command")
    public Result updateCageControl(@RequestBody CageControl cageControl) {
        // 1. 立即执行原有的喂食/喂水逻辑
        if (Boolean.TRUE.equals(cageControl.getFeed())) {
            FeedRecord feedRecord = new FeedRecord();
            feedRecord.setFeedType(false);
            feedRecord.setPetId(1);
            feedRecordService.insertFeedRecord(feedRecord);
        }
        if (Boolean.TRUE.equals(cageControl.getWater())) {
            WaterRecord waterRecord = new WaterRecord();
            waterRecord.setWaterType(false);
            waterRecord.setPetId(1);
            waterRecordService.insertWaterRecord(waterRecord);
        }

        // 2. 立即更新开关状态为true（前端看到开关打开）
        cageService.updateCageControlStatus(cageControl);

        // 3. 异步触发2秒后自动关闭
        if (Boolean.TRUE.equals(cageControl.getFeed()) || Boolean.TRUE.equals(cageControl.getWater())|| Boolean.TRUE.equals(cageControl.getCageDoor())) {
            CageControl delayControl = new CageControl();
            BeanUtils.copyProperties(cageControl, delayControl);

            // 你要写死 id=1 → 保留
            delayControl.setId(1);

            // 异步复位（2 秒）
            cageService.autoResetControlStatus(delayControl, 8);
        }

        return Result.success();
    }
    @PutMapping("/cage/control/auto-command")
    public Result autoUpdateCageControl(@RequestBody CageControl cageControl){
        if(Boolean.TRUE.equals(cageControl.getFeed())){
            FeedRecord feedRecord = new FeedRecord();
            feedRecord.setFeedType(true);
            feedRecord.setPetId(1);
            feedRecordService.insertFeedRecord(feedRecord);
        }
        if(Boolean.TRUE.equals(cageControl.getWater())){
            WaterRecord waterRecord = new WaterRecord();
            waterRecord.setWaterType(true);
            waterRecord.setPetId(1);
            waterRecordService.insertWaterRecord(waterRecord);
        }
        cageService.updateCageControlStatus(cageControl);
        return Result.success();
    }
    @PutMapping("/cage/fill-status")
    public Result insertCageStatus(@RequestBody CageEnv cageEnv){
        cageService.insertCageStatus(cageEnv);
        return Result.success();
    }

}
