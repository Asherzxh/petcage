package org.example.petcage.mapper;

import org.apache.ibatis.annotations.Delete;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import java.util.List;
import java.util.Map;

@Mapper
public interface RecordMapper {
    List<Map<String, Object>> pageQuery(@Param("tableName") String tableName);
        // ================== 新增下面 3 个 ==================
// 删除1天前的喂食记录
        @Delete("DELETE FROM feed_record WHERE feed_time < DATE_SUB(NOW(), INTERVAL #{days} DAY)")
        void deleteFeedingByDays(@Param("days") int days);

    // 删除1天前的加水记录
    @Delete("DELETE FROM water_record WHERE water_time < DATE_SUB(NOW(), INTERVAL #{days} DAY)")
    void deleteWateringByDays(@Param("days") int days);

    // 删除1天前的预警记录
    @Delete("DELETE FROM warning_record WHERE warning_time < DATE_SUB(NOW(), INTERVAL #{days} DAY)")
    void deleteWarningByDays(@Param("days") int days);

}