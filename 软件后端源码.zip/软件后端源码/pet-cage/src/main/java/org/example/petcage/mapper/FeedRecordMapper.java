package org.example.petcage.mapper;

import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Mapper;
import org.example.petcage.pojo.FeedRecord;

@Mapper
public interface FeedRecordMapper {
    @Insert("insert into feed_record ( pet_id, feed_type, feed_time) values (#{petId},#{feedType},#{feedTime})")
    void insertFeedRecord(FeedRecord feedRecord);
}
