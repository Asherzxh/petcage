package org.example.petcage.VO;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;

import java.io.Serializable;

@Data
@Builder
@AllArgsConstructor
public class UserVO implements Serializable {

    private Integer id;           // 可以返回
    private String username;      // 可以返回
    private String url;           // 头像，可以返回

}