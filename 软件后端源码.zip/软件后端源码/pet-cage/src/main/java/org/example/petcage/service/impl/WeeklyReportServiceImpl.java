package org.example.petcage.service.impl;

import lombok.RequiredArgsConstructor;
import org.example.petcage.mapper.WeeklyReportMapper;
import org.example.petcage.pojo.PetWeeklyReport;
import org.example.petcage.service.WeeklyReportService;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;
import java.time.LocalDateTime;
import java.util.List;

@Service
@RequiredArgsConstructor
public class WeeklyReportServiceImpl implements WeeklyReportService {

    private final WeeklyReportMapper weeklyReportMapper;

    /**
     * 你【随时调用】：只刷新本周数据，不交换
     */
    @Override
    public void initializeReport(String id) {
        Integer petId = Integer.valueOf(id);

        // 查询最新统计
        PetWeeklyReport report = weeklyReportMapper.selectWeeklyData(petId);
        report.setPetId(petId);
        report.setStartTime(LocalDateTime.now().minusDays(7));
        report.setEndTime(LocalDateTime.now());
        report.setPetStatus("正常");
        report.setAiEvaluation("本周实时统计数据");

        // 只更新本周（week_type=1）
        weeklyReportMapper.insertOrUpdateWeek(report);
    }
    public PetWeeklyReport getReport(Integer petId, Integer type) {
        return weeklyReportMapper.getReportByType(petId, type);
    }
    /**
     * 【每周一 00:00 自动交换】7天一次
     */
    @Scheduled(cron = "0 0 0 * * MON")
    public void autoSwapWeek() {
        List<Integer> petIds = weeklyReportMapper.getAllPetIds();
        for (Integer petId : petIds) {
            weeklyReportMapper.shiftToLastWeek(petId);
        }
    }
}