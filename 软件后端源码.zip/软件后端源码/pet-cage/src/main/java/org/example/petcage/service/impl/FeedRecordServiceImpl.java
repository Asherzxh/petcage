package org.example.petcage.service.impl;

import org.example.petcage.mapper.FeedRecordMapper;
import org.example.petcage.pojo.FeedRecord;
import org.example.petcage.service.FeedRecordService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;

@Service
public class FeedRecordServiceImpl implements FeedRecordService {
    @Autowired
    private FeedRecordMapper feedRecordMapper;
    @Override
    public void insertFeedRecord(FeedRecord feedRecord) {
        feedRecord.setFeedTime(LocalDateTime.now());
        feedRecordMapper.insertFeedRecord(feedRecord);

    }
}
