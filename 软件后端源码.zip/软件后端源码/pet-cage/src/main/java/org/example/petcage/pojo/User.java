package org.example.petcage.pojo;

import lombok.Data;

@Data
public class User {
    private Integer id;          // 主键ID
    private String username;     // 用户名
    private String url;          // 头像URL
    private String password;     // 密码
    private String email;        // 邮箱
    private String emailCode;    // 邮箱授权码（用于发送邮件）
}