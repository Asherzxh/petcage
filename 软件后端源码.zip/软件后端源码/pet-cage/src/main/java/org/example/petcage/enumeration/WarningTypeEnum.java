package org.example.petcage.enumeration;

/**
 * 预警类型枚举
 */

public enum WarningTypeEnum {

    // 生命体征
    HEART_RATE_ABNORMAL("宠物心率异常"),
    BLOOD_OXYGEN_ABNORMAL("宠物血氧异常"),
    TEMPERATURE_ABNORMAL("宠物体温异常"),

    // 环境监测
    AMBIENT_TEMP("环境温度异常"),
    HUMIDITY("笼内湿度异常"),
    AIR_QUALITY_ABNORMAL("空气质量异常"),

    // 饮食供应
    FOOD_LOW("宠物食物不足"),
    WATER_LOW("宠物水量不足"),

    // 其他
    DEVICE_ABNORMAL("设备异常"),
    UNKNOWN_ABNORMAL("未知异常"),
    USER_NOT_EXIST("用户不存在"),
    USER_PASSWORD_WRONG("用户密码错误");
    private final String warningType;

    WarningTypeEnum(String warningType) {
        this.warningType = warningType;
    }

    public String getWarningType() {
        return warningType;
    }
}