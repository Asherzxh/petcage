package org.example.petcage.task;

import org.example.petcage.mapper.RecordMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

@Component
public class DataCleanTask {

    @Autowired
    private RecordMapper recordMapper;

    // ===================== 核心 =====================
    // 每 7 天执行 1 次（每周一 凌晨 2 点）
    @Scheduled(cron = "0 0 2 ? * MON")


    public void cleanDataEvery7Days() {
        System.out.println("开始执行7天自动清理～");

        // 删除 7 天前的喂食记录
        recordMapper.deleteFeedingByDays(7);

        // 删除 7 天前的加水记录
        recordMapper.deleteWateringByDays(7);

        // 删除 7 天前的预警记录
        recordMapper.deleteWarningByDays(7);

        System.out.println("7天前旧数据已自动删除！");
    }
}