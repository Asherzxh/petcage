package org.example.petcage.exception;

/**
 * 自定义业务异常（我们主动抛出的异常）
 */
public class BusinessException extends RuntimeException {

    public BusinessException(String message) {
        super(message);
    }
}