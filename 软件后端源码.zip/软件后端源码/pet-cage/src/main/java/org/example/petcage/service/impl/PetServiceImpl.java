package org.example.petcage.service.impl;

import org.example.petcage.mapper.PetMapper;
import org.example.petcage.pojo.Pet;
import org.example.petcage.pojo.PetHealth;
import org.example.petcage.pojo.PetWeeklyReport;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;

@Service

public class PetServiceImpl {

    @Autowired
    private PetMapper petMapper;
    public PetHealth getById(String id) {
        return petMapper.getById(id);
    }

    public Pet getInformationById(String id) {
        Pet information = petMapper.getInformationById(id);
        return information;
    }

    public PetWeeklyReport getReportById(String id) {
        PetWeeklyReport report = petMapper.getReportById(id);
        return report;
    }

    public void updateStatus(PetHealth petHealth) {
        petHealth.setCreateTime(LocalDateTime.now());
        petMapper.updateStatus(petHealth);
    }
}
