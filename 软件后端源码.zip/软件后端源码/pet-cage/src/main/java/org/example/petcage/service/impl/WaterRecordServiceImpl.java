package org.example.petcage.service.impl;


import org.example.petcage.mapper.WaterRecordMapper;
import org.example.petcage.pojo.WaterRecord;
import org.example.petcage.service.WaterRecordService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;

@Service
public class WaterRecordServiceImpl implements WaterRecordService {
        @Autowired
        private WaterRecordMapper waterRecordMapper;
        @Override
        public void insertWaterRecord(WaterRecord waterRecord) {
            waterRecord.setWaterTime(LocalDateTime.now());
            waterRecordMapper.insertWaterRecord(waterRecord);

        }
    }
