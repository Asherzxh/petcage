package org.example.petcage.service;

import org.example.petcage.pojo.PetHealth;

public interface PetService {
    PetHealth getById(String id);
}
