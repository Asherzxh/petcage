package org.example.petcage.pojo;

import lombok.Data;
import java.time.LocalDateTime;

@Data
public class CageEnv {
    private Integer id;              // 主键
    private Integer cageId;          // 笼子ID
    private Float cageTemperature;   // 笼子温度
    private Float humidity;          // 湿度
    private Float organicGas;       // 有机气体
    private Float carbonDioxide;     // 二氧化碳
    private Float food;              // 食物
    private Float water;             // 水
    private LocalDateTime createTime;// 采集时间
}