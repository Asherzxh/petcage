package org.example.petcage.pojo;

import lombok.Data;

@Data
public class Cage {
    private Integer id;          // 主键（笼子ID）
    private Integer petId;       // 绑定宠物ID
    private Integer userId;      // 用户ID
}