package org.example.petcage.pojo;

import lombok.Data;
import java.time.LocalDateTime;

@Data
public class PetWeeklyReport {
    private Integer id;              // 主键
    private Integer petId;           // 宠物ID
    private LocalDateTime startTime; // 开始时间
    private LocalDateTime endTime;   // 结束时间
    private Integer abnormalCount;   // 异常次数
    private Integer foodSupplyCount; // 食物补充次数
    private Integer waterAddCount;   // 加水次数
    private Integer fecesCleanCount; // 清理次数
    private String petStatus;        // 宠物状态
    private String aiEvaluation;     // AI评估
    private Integer weekType;
}