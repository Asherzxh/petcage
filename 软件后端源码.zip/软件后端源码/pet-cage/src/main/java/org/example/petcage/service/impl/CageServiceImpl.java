package org.example.petcage.service.impl;

import lombok.extern.slf4j.Slf4j;
import org.example.petcage.enumeration.WarningTypeEnum;
import org.example.petcage.exception.BusinessException;
import org.example.petcage.mapper.CageMapper;
import org.example.petcage.pojo.CageControl;
import org.example.petcage.pojo.CageEnv;
import org.example.petcage.service.CageService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;

@Service
public class CageServiceImpl implements CageService {
    @Autowired
    private CageMapper cageMapper;
    @Override
    public CageEnv getCageStatus() {
        return cageMapper.getCageStatus();
    }

    @Override
    public CageControl getCageControlStatus() {
        return cageMapper.getCageControlStatus();
    }

    @Override
    public void updateCageControlStatus(CageControl cageControl) {
        cageControl.setCreateTime(LocalDateTime.now());
        cageMapper.updateCageControlStatus(cageControl);
    }
    @Async
    @Override
    public void autoResetControlStatus(CageControl cageControl, int delaySeconds) {
        try {
            // 等待 2 秒
            Thread.sleep(delaySeconds * 1000L);

            // 强制关闭
            cageControl.setFeed(false);
            cageControl.setWater(false);
            cageControl.setCageDoor(false);

            // 关键：确保 id=1 被带到更新语句里
            cageControl.setId(1);

            // 更新数据库
            updateCageControlStatus(cageControl);

            System.out.println("✅ 2秒后已自动关闭喂食/喂水，id=1");

        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }
    }
    @Override
    public void insertCageStatus(CageEnv cageEnv) {
        cageEnv.setCreateTime(LocalDateTime.now());
        cageMapper.insertCageStatus(cageEnv);
        if (cageEnv.getCageTemperature() < 20 || cageEnv.getCageTemperature() > 28) {
            throw new BusinessException(WarningTypeEnum.AMBIENT_TEMP.getWarningType());
        }

        // 2. 湿度 >70 异常
        if (cageEnv.getHumidity() > 70) {
            throw new BusinessException(WarningTypeEnum.HUMIDITY.getWarningType());
        }

        // 3. CO2 >1200 + TVOC>800 → 空气质量异常
        if (cageEnv.getCarbonDioxide() > 1200 || cageEnv.getOrganicGas() > 800) {
            throw new BusinessException(WarningTypeEnum.AIR_QUALITY_ABNORMAL.getWarningType());
        }

        // 4. 食物 <20 → 食物不足
        if (cageEnv.getFood() < 20) {
            throw new BusinessException(WarningTypeEnum.FOOD_LOW.getWarningType());
        }

        // 5. 水 <20 → 水量不足
        if (cageEnv.getWater() < 20) {
            throw new BusinessException(WarningTypeEnum.WATER_LOW.getWarningType());
        }
    }
}
