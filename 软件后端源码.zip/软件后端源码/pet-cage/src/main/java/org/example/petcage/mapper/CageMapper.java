package org.example.petcage.mapper;

import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Select;
import org.example.petcage.pojo.CageControl;
import org.example.petcage.pojo.CageEnv;

@Mapper
public interface CageMapper {
    @Select("select *from cage_env where id =1")
    CageEnv getCageStatus();
    @Select("select *from cage_control where id =1")
    CageControl getCageControlStatus();

    void updateCageControlStatus(CageControl cageControl);
    @Insert("INSERT INTO cage_env (\n" +
            "    cage_id,\n" +
            "    cage_temperature,\n" +
            "    humidity,\n" +
            "    organic_gas,\n" +
            "    carbon_dioxide,\n" +
            "    food,\n" +
            "    water,\n" +
            "    create_time\n" +
            ") VALUES (\n" +
            "    1,\n" +
            "    #{cageTemperature},\n" +
            "    #{humidity},\n" +
            "    #{organicGas},\n" +
            "    #{carbonDioxide},\n" +
            "    #{food},\n" +
            "    #{water},\n" +
            "    #{createTime}\n" +
            ");")
    void insertCageStatus(CageEnv cageEnv);
}
