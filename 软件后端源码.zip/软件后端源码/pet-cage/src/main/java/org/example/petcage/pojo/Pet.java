package org.example.petcage.pojo;

import lombok.Data;

@Data
public class Pet {
    private Integer id;          // 主键（宠物ID）
    private String petName;      // 昵称
    private Integer userId;      // 用户ID
}