package org.example.petcage.pojo;

import lombok.Data;
import java.time.LocalDateTime;

@Data
public class CageControl {
    private Integer id;              // 主键
    private Integer cageId;          // 笼子ID
    private Boolean cageDoor;        // 笼门
    private Boolean ventilation;     // 换气
    private Boolean feed;            // 喂食
    private Boolean water;           // 加水
    private Boolean clean;           // 清理粪便
    private LocalDateTime createTime;// 操作时间
}