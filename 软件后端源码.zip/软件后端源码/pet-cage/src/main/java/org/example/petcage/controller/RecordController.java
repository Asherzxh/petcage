package org.example.petcage.controller;

import org.example.petcage.result.PageResult;
import org.example.petcage.result.Result;
import org.example.petcage.service.RecordService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class RecordController {

    @Autowired
    private RecordService recordService;

    // 喂食记录
    @GetMapping("/feeding-record")
    public Result<PageResult> feedingRecord(
            @RequestParam(defaultValue = "1") Integer page,
            @RequestParam(defaultValue = "10") Integer pageSize) {
        PageResult pageResult = recordService.pageQuery("feed_record", page, pageSize);
        return Result.success(pageResult);
    }

    // 加水记录
    @GetMapping("/watering-record")
    public Result<PageResult> wateringRecord(
            @RequestParam(defaultValue = "1") Integer page,
            @RequestParam(defaultValue = "10") Integer pageSize) {
        PageResult pageResult = recordService.pageQuery("water_record", page, pageSize);
        return Result.success(pageResult);
    }

    // 预警记录
    @GetMapping("/warning-record")
    public Result<PageResult> warningRecord(
            @RequestParam(defaultValue = "1") Integer page,
            @RequestParam(defaultValue = "10") Integer pageSize) {
        PageResult pageResult = recordService.pageQuery("warning_record", page, pageSize);
        return Result.success(pageResult);
    }
}