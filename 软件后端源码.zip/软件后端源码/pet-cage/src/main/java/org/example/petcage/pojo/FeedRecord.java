package org.example.petcage.pojo;

import lombok.Data;
import java.time.LocalDateTime;

@Data
public class FeedRecord {
    private Integer id;              // 主键
    private Integer petId;           // 宠物ID
    private Boolean feedType;        // 0人工 1自动
    private LocalDateTime feedTime;  // 喂食时间
}