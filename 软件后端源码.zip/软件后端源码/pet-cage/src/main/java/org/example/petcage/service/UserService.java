package org.example.petcage.service;

import org.example.petcage.DTO.UserLoginDTO;
import org.example.petcage.pojo.User;



public interface UserService {
    User login(UserLoginDTO dto);

    User getUserById(String id);
}
