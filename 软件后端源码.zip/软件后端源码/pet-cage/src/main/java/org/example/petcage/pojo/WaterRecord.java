package org.example.petcage.pojo;

import lombok.Data;
import java.time.LocalDateTime;

@Data
public class WaterRecord {
    private Integer id;              // 主键
    private Integer petId;           // 宠物ID
    private Boolean waterType;       // 0人工 1自动
    private LocalDateTime waterTime; // 喂水时间
}