package org.example.petcage.mapper;

import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.annotations.Update;
import org.example.petcage.pojo.User;

@Mapper
public interface UserMapper {

    @Select("select * from user where username=#{username}")
    User getByUserName(String username);

    @Select("select * from user where id=#{id}")
    User getUserById(String id);

    void updateUser(User user);
}