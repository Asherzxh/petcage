package org.example.petcage.service;

import org.example.petcage.result.PageResult;

public interface RecordService {
    PageResult pageQuery(String tableName, Integer page, Integer pageSize);
}