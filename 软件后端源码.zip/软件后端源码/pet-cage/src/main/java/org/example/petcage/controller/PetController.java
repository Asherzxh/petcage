package org.example.petcage.controller;

import org.example.petcage.mapper.PetMapper;
import org.example.petcage.pojo.Pet;
import org.example.petcage.pojo.PetHealth;
import org.example.petcage.result.Result;
import org.example.petcage.service.WeeklyReportService;
import org.example.petcage.service.impl.PetServiceImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@RestController
public class PetController {
    @Autowired
    public PetServiceImpl petService;
    @Autowired
    private PetMapper petMapper;
    @Autowired
    private WeeklyReportService weeklyReportService;

    @GetMapping("/pet/status/{id}")
    public Result petStatus(@PathVariable String id){
    PetHealth petHealth = petService.getById(id);
    return Result.success(petHealth);
}
@GetMapping("/pet/info/{id}")
    public Result petInformation(@PathVariable String id){
    Pet information = petService.getInformationById(id);
    return Result.success(information);
}
@PutMapping("/pet/update")
    public Result petUpdate(@RequestBody Pet pet){
    petMapper.updateByPetId(pet);
    return Result.success();
}
@GetMapping("/pet/report/weekly/{petId}")
public Result getReport(
        @PathVariable Integer petId,    // 只传宠物ID 1
        @RequestParam Integer type      // 1本周 2上周
) {
    return Result.success(weeklyReportService.getReport(petId, type));
}
@PutMapping("/pet/statue-update")
    public Result petStatueUpdate(@RequestBody PetHealth petHealth){
        petService.updateStatus(petHealth);
        return Result.success();
}
}
