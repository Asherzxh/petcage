package org.example.petcage.handler;

import lombok.extern.slf4j.Slf4j;

import org.example.petcage.exception.BusinessException;
import org.example.petcage.result.Result;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

/**
 * 全局异常处理器
 * 捕获项目所有异常，统一返回格式
 */
@RestControllerAdvice
@Slf4j
public class GlobalExceptionHandler {

    /**
     * 捕获 自定义业务异常（我们自己手动抛出的异常）
     */
    @ExceptionHandler(BusinessException.class)
    public Result handleBusinessException(BusinessException e) {
        log.error("业务异常：{}", e.getMessage());
        return Result.error(e.getMessage());
    }

    /**
     * 捕获 参数校验异常（@Valid 校验失败）
     */
    @ExceptionHandler(IllegalArgumentException.class)
    public Result handleIllegalArgumentException(IllegalArgumentException e) {
        log.error("参数异常：{}", e.getMessage());
        return Result.error(e.getMessage());
    }

    /**
     * 捕获 所有其他异常（兜底）
     */
    @ExceptionHandler(Exception.class)
    public Result handleException(Exception e) {
        log.error("系统异常：", e);
        return Result.error("服务器异常，请联系管理员");
    }
}