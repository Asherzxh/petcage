package org.example.petcage.mapper;

import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.annotations.Update;
import org.example.petcage.pojo.Pet;
import org.example.petcage.pojo.PetHealth;
import org.example.petcage.pojo.PetWeeklyReport;

@Mapper
public interface PetMapper {
    @Select("select *from pet_health where id=#{petId}")
    PetHealth getById(String id);
    @Select("select *from pet where id=1")
    Pet getInformationById(String id);
    @Update("UPDATE pet\n" +
            "        SET \n" +
            "            pet_name = #{petName},\n" +
            "            user_id = #{userId}\n" +
            "        WHERE id = #{id}")
    void updateByPetId(Pet pet);
    @Select("select *from pet_weekly_report where id =#{id}")
    PetWeeklyReport getReportById(String id);
@Insert("INSERT INTO pet_health (\n" +
        "    pet_id,\n" +
        "    heart_rate,\n" +
        "    blood_oxygen,\n" +
        "    body_temperature,\n" +
        "    create_time\n" +
        ") VALUES (\n" +
        "    #{petId},\n" +
        "    #{heartRate},\n" +
        "    #{bloodOxygen},\n" +
        "    #{bodyTemperature},\n" +
        "    #{createTime}\n" +
        ");")
    void updateStatus(PetHealth petHealth);
}
