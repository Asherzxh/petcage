package org.example.petcage.service.impl;

import lombok.extern.slf4j.Slf4j;
import org.example.petcage.mapper.RecordMapper;
import org.example.petcage.result.PageResult;
import org.example.petcage.service.RecordService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.github.pagehelper.Page;
import com.github.pagehelper.PageHelper;

import java.util.List;
import java.util.Map;

@Service
@Slf4j
public class RecordServiceImpl implements RecordService {

    @Autowired
    private RecordMapper recordMapper;

    @Override
    public PageResult pageQuery(String tableName, Integer page, Integer pageSize) {
        // 关键：必须在 mapper 查询之前开启分页
        PageHelper.startPage(page, pageSize);

        // 查询数据
        List<Map<String, Object>> list = recordMapper.pageQuery(tableName);

        // 强转成 Page 就能获取 total
        Page<Map<String, Object>> pageList = (Page<Map<String, Object>>) list;

        return new PageResult(pageList.getTotal(), pageList.getResult());
    }
}