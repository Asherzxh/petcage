package org.example.petcage.controller;

import org.example.petcage.DTO.UserLoginDTO;
import org.example.petcage.VO.UserLoginVO;
import org.example.petcage.VO.UserVO;
import org.example.petcage.config.BaseContext;
import org.example.petcage.mapper.UserMapper;
import org.example.petcage.pojo.User;
import org.example.petcage.properties.JwtProperties;
import org.example.petcage.result.Result;
import org.example.petcage.service.UserService;
import org.example.petcage.util.AliOssUtil;
import org.example.petcage.util.JwtUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

@RestController
public class UserController {
    @Autowired
    public UserService userService;
    @Autowired
    public JwtProperties jwtProperties;
    @Autowired
    private UserMapper userMapper;
    @Autowired
    private AliOssUtil aliOssUtil;
    @PostMapping("/login")
    public Result login(@RequestBody UserLoginDTO dto) {
        User user = userService.login(dto);
        Map<String, Object> claims = new HashMap<>();
        claims.put("userId", user.getId());
        String token = JwtUtil.createJWT(
                jwtProperties.getAdminSecretKey(),
                jwtProperties.getAdminTtl(),
                claims);

        UserLoginVO userLoginVO = UserLoginVO.builder()
                .id(user.getId())
                .url(user.getUrl())
                .username(user.getUsername())
                .token(token)
                .build();
        return Result.success(userLoginVO);
    }
    @GetMapping("/user/info/{id}")
    public Result getUserInfo(@PathVariable String id) {
        User user =userService.getUserById(id);
        return Result.success(user);
    }
    @GetMapping("/user/profile/{id}")
    public Result getUserProfile(@PathVariable String id) {
        User user = userService.getUserById(id);
        UserVO userVO = new UserVO(user.getId(),user.getUsername(),user.getUrl());
        return Result.success(userVO);
    }
    @PutMapping("/user/update")
    public Result updateUser(@RequestBody User user) {
        user.setId(Math.toIntExact(BaseContext.getCurrentId()));
        userMapper.updateUser(user);
        return Result.success();
    }

    @PostMapping("/upload")
    public Result upload(MultipartFile file) throws IOException {
        String fileName = file.getOriginalFilename();
        String suffixName = fileName.substring(fileName.lastIndexOf("."));
        String name = UUID.randomUUID().toString() + suffixName;
        String filePath =aliOssUtil.upload(file.getBytes(),name);
        return Result.success(filePath);
    }
}
