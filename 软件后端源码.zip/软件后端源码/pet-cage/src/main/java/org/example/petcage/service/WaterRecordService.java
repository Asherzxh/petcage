package org.example.petcage.service;

import org.example.petcage.pojo.WaterRecord;

public interface WaterRecordService {
    void insertWaterRecord(WaterRecord waterRecord);
}
