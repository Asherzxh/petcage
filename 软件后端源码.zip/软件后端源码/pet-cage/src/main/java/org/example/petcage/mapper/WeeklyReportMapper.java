package org.example.petcage.mapper;

import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.annotations.Update;
import org.example.petcage.pojo.PetWeeklyReport;
import java.util.List;

@Mapper
public interface WeeklyReportMapper {

        @Select("SELECT * FROM pet_weekly_report WHERE pet_id = #{petId} AND week_type = #{type}")
        PetWeeklyReport getReportByType(@Param("petId") Integer petId, @Param("type") Integer type);
    // 查询统计数据
    @Select("""
        SELECT
            p.id AS petId,
            IFNULL(COUNT(DISTINCT w.id), 0) AS abnormalCount,
            IFNULL(COUNT(DISTINCT f.id), 0) AS foodSupplyCount,
            IFNULL(COUNT(DISTINCT wt.id), 0) AS waterAddCount,
            IFNULL(COUNT(DISTINCT cc.id), 0) AS fecesCleanCount
        FROM pet p
        LEFT JOIN cage c ON p.id = c.pet_id
        LEFT JOIN cage_control cc ON c.id = cc.cage_id AND cc.clean = 1
        LEFT JOIN feed_record f ON p.id = f.pet_id
        LEFT JOIN water_record wt ON p.id = wt.pet_id
        LEFT JOIN warning_record w ON p.id = w.pet_id
        WHERE p.id = #{petId}
        GROUP BY p.id
    """)
    PetWeeklyReport selectWeeklyData(@Param("petId") Integer petId);

    // ==========================================
    // 每周自动交换：本周 → 上周
    // ==========================================
    @Update("""
        UPDATE pet_weekly_report
        SET week_type = 2
        WHERE pet_id = #{petId} AND week_type = 1
    """)
    void shiftToLastWeek(@Param("petId") Integer petId);

    // ==========================================
    // 插入/更新 本周数据
    // ==========================================
    @Update("""
        INSERT INTO pet_weekly_report(
            pet_id, week_type, start_time, end_time,
            abnormal_count, food_supply_count, water_add_count,
            feces_clean_count, pet_status, ai_evaluation
        )
        VALUES(
            #{petId}, 1, #{startTime}, #{endTime},
            #{abnormalCount}, #{foodSupplyCount}, #{waterAddCount},
            #{fecesCleanCount}, #{petStatus}, #{aiEvaluation}
        )
        ON DUPLICATE KEY UPDATE
            abnormal_count = #{abnormalCount},
            food_supply_count = #{foodSupplyCount},
            water_add_count = #{waterAddCount},
            feces_clean_count = #{fecesCleanCount},
            start_time = #{startTime},
            end_time = #{endTime}
    """)
    void insertOrUpdateWeek(PetWeeklyReport report);

    // 获取所有宠物ID（定时任务用）
    @Select("SELECT id FROM pet")
    List<Integer> getAllPetIds();
}