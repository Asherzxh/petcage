package org.example.petcage.mapper;

import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Mapper;
import org.example.petcage.pojo.FeedRecord;
import org.example.petcage.pojo.WaterRecord;

@Mapper
public interface WaterRecordMapper {
    @Insert("insert into water_record ( pet_id, water_type, water_time) values (#{petId},#{waterType},#{waterTime})")
    void insertWaterRecord(WaterRecord waterRecord);

}
