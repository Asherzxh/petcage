const s="/assets/Avatar-8ZMutlIm.jpg";export{s as _};
