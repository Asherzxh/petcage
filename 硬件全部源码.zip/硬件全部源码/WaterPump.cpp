#include "WaterPump.h"

WaterPump::WaterPump() {
  _isRunning = false;
}

bool WaterPump::begin() {
  pinMode(PUMP_RELAY_PIN, OUTPUT);
  off();  // 默认关闭
  return true;
}

void WaterPump::on() {
  digitalWrite(PUMP_RELAY_PIN, RELAY_ON_LEVEL);
  _isRunning = true;
}

void WaterPump::off() {
  digitalWrite(PUMP_RELAY_PIN, !RELAY_ON_LEVEL);
  _isRunning = false;
}

bool WaterPump::isRunning() {
  return _isRunning;
}