#include "FanController.h"

bool FanController::begin() {
  pinMode(_pwmPin, OUTPUT);
  ledcSetup(0, 5000, 8); // 通道0，5kHz PWM，8位精度（0-255）
  ledcAttachPin(_pwmPin, 0);
  setSpeed(FAN_STOP); // 初始停止
  _isReady = true;
  Serial.println("✅ 风扇控制器初始化成功");
  return true;
}

void FanController::setSpeed(uint8_t speed) {
  if (!_isReady) return;
  // 限制速度范围
  speed = constrain(speed, FAN_STOP, FAN_FULL_SPEED);
  ledcWrite(0, speed); // 写入PWM值
  Serial.printf("💨 风扇速度设置为：%d\n", speed);
}