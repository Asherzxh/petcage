#include "ServoMotor.h"
#include <Arduino.h>
#include "esp32-hal-ledc.h" 
ServoMotor::ServoMotor() {
  _currentAngle = 90;
  _isReady = false;
}

bool ServoMotor::begin() {
  // SG90 标准 PWM 参数

    ledcSetup(SERVO_CH, 50, 10);  // 50Hz, 10bit
  ledcAttachPin(SERVO_PIN, SERVO_CH);
  _isReady = true;
  setAngle(0);  // 上电默认90度
  return true;
  
}

void ServoMotor::setAngle(uint8_t angle) {
  if (!_isReady) return;

  if (angle > 180) angle = 180;
  if (angle < 0) angle = 0;

  // SG90 角度 -> PWM 计算
  int pulseWidth = map(angle, 0, 180, 26, 123);
  ledcWrite(SERVO_CH, pulseWidth);
  _currentAngle = angle;
}

uint8_t ServoMotor::getAngle() {
  return _currentAngle;
}