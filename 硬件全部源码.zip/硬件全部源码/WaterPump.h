#ifndef WATER_PUMP_H
#define WATER_PUMP_H

#include <Arduino.h>
#include "Config.h"

class WaterPump {
private:
  bool _isRunning;

public:
  WaterPump();

  // 初始化
  bool begin();

  // 打开水泵
  void on();

  // 关闭水泵
  void off();

  // 获取状态
  bool isRunning();
};

#endif