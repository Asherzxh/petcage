#include "GasSensorSGP30.h"

bool GasSensorSGP30::begin() {
  if (_sgp.begin()) { // SGP30默认地址0x58，无需手动指定
    _isReady = true;
    Serial.println("✅ SGP30初始化成功");
    // 初始化基线（提升精度）
    _sgp.IAQinit();
    return true;
  } else {
    Serial.println("❌ SGP30初始化失败");
    _isReady = false;
    return false;
  }
}

bool GasSensorSGP30::readData() {
  if (!_isReady) return false;

  if (_sgp.IAQmeasure()) {
    _eco2 = _sgp.eCO2;
    _tvoc = _sgp.TVOC;
    return true;
  } else {
    Serial.println("❌ SGP30数据读取失败");
    return false;
  }
}