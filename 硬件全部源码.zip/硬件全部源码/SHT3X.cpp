#include "SHT3X.h"

bool SHT3X::begin() {
  // 仅初始化传感器，I2C由主程序统一初始化
  if (_sht.begin(0x44)) { // SHT3X默认地址0x44
    _isReady = true;
    Serial.println("✅ SHT3X初始化成功");
    return true;
  } else {
    Serial.println("❌ SHT3X初始化失败");
    _isReady = false;
    return false;
  }
}

bool SHT3X::readData() {
  if (!_isReady) return false;

  float temp = _sht.readTemperature();
  float humi = _sht.readHumidity();

  if (!isnan(temp) && !isnan(humi)) {
    _temperature = temp;
    _humidity = humi;
    return true;
  } else {
    Serial.println("❌ SHT3X数据读取失败");
    return false;
  }
}