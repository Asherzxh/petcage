#include <Wire.h>
#include "MAX30105.h"
#include <spo2_algorithm.h> // 库自带的血氧与心率综合算法
#include <WiFi.h>
#include "HTTPClient.h"

MAX30105 particleSensor;

HTTPClient http;

// 定义缓冲区长度（算法要求必须是 100 个连续采样点）
#define BUFFER_SIZE 100
uint32_t irBuffer[BUFFER_SIZE];  // 红外光数据缓冲区
uint32_t redBuffer[BUFFER_SIZE]; // 红光数据缓冲区

int32_t bufferLength;  // 实际缓冲区长度
int32_t spo2;          // 计算得出的血氧值
int8_t validSPO2;      // 血氧计算是否有效 (1=有效, 0=无效)
int32_t heartRate;     // 计算得出的心率值
int8_t validHeartRate; // 心率计算是否有效 (1=有效, 0=无效)

const char* ssid     = "";
const char* password = "";
const char* DATA_SERVER_URL = "";

void connectWiFi();
void SendData(String postData);

void setup() {
  Serial.begin(115200);
  delay(10);
  connectWiFi();
  Wire.begin(21,22); // ESP32 I2C 引脚

  Serial.println("Initializing MAX30102...");

  if (!particleSensor.begin(Wire, I2C_SPEED_FAST)) {
    Serial.println("MAX30102 not found. Check wiring.");
    while (1);
  }

  // --- 传感器核心配置 ---
  byte ledBrightness = 0x3A; 
  byte sampleAverage =16;    // 采样平均 (4次平均，过滤杂波)
  byte ledMode = 2;          // 必须设为 2 (Red + IR) 才能测血氧
  int sampleRate = 100;      // 采样率 100Hz (配合 100 的缓冲区刚好是 1 秒的数据)
  int pulseWidth = 411;      // 脉冲宽度
  int adcRange = 16384;      // ADC 范围

  particleSensor.setup(ledBrightness, sampleAverage, ledMode, sampleRate, pulseWidth, adcRange);

  Serial.println("Place your finger on the sensor. Reading initial data...");
  bufferLength = BUFFER_SIZE;

  // 1. 初始化阶段：先填满前 100 个采样点
  for (byte i = 0; i < bufferLength; i++) {
    while (particleSensor.available() == false) {
      particleSensor.check(); // 等待新数据
    }
    redBuffer[i] = particleSensor.getRed();
    irBuffer[i] = particleSensor.getIR();
    particleSensor.nextSample(); // 移动到下一个样本
  }
}

static int lastStableHR = 75;
static int lastStableSpO2 = 98;

void loop() {
  // 1. 调用核心算法计算
  maxim_heart_rate_and_oxygen_saturation(irBuffer, bufferLength, redBuffer, &spo2, &validSPO2, &heartRate, &validHeartRate);

  // 2. 内存平移（保持不变）
  for (byte i = 25; i < 100; i++) {
    redBuffer[i - 25] = redBuffer[i];
    irBuffer[i - 25] = irBuffer[i];
  }

  // 3. 读取新数据并实时输出过滤后的结果
  for (byte i = 75; i < 100; i++) {
    // 在 setup 和 loop 的 while 循环中加入超时判断
    long startTime = millis();
    while (particleSensor.available() == false) {
       particleSensor.check();
       if (millis() - startTime > 500) { // 如果 500ms 没收到数据，强制重启传感器
          Serial.println("Sensor Timeout! Resetting...");
          particleSensor.setup(); 
          break;
          }
       } 
    
    redBuffer[i] = particleSensor.getRed();
    irBuffer[i] = particleSensor.getIR();
    particleSensor.nextSample(); 

    
    if (irBuffer[i] > 20000) { 
      // --- 核心优化：心率过滤器 ---
      Serial.print("HR: ");
      // 只有当算法认为有效，且数值在正常人类范围(45-185)内时才更新
      if (validHeartRate && heartRate > 45 && heartRate < 185) {
        // 加权平均，让数值变动更丝滑 (30%新值 + 70%旧值)
        lastStableHR = (75*0.5)+(lastStableHR * 0.3) + (heartRate * 0.2);
        Serial.print(lastStableHR);
        Serial.print(" bpm");
      } else {
        Serial.print(lastStableHR); // 遇到异常值时，显示上一次稳定的值
        Serial.print(" (Stable)");
      }

      // --- 核心优化：血氧过滤器 ---
      Serial.print("\tSpO2: ");
      // 只有当有效且大于 85 时才认为可信（70% 通常是误报）
      if (validSPO2 && spo2 > 85 && spo2 <= 100) {
        lastStableSpO2 = spo2;
        Serial.print(lastStableSpO2);
        Serial.print(" %");
      } else {
        Serial.print(lastStableSpO2);
        Serial.print(" (Stable)");
      }

      float temp = particleSensor.readTemperature();
      Serial.print("\tTemp: ");
      Serial.print(temp, 1);
      Serial.println(" C");

      // ==========================================
      // 将数据转换为 JSON 格式并打印 👇
      // ==========================================
      
      // 定义一个静态变量记录上次生成 JSON 的时间
      static unsigned long lastJsonTime = 0;
      
      // 每隔 3000 毫秒（10秒）生成并输出一次 JSON 数据，避免刷屏
      if (millis() - lastJsonTime > 10000) {
          
          // 拼接 JSON 字符串 (注意转义字符 \")
          String jsonPayload = "{";
          jsonPayload += "\"heartRate\":" + String(lastStableHR) + ",";
          jsonPayload += "\"spo2\":" + String(lastStableSpO2) + ",";
          jsonPayload += "\"temperature\":" + String(temp, 1); // 保留1位小数
          jsonPayload += "}";

          // 打印最终生成的 JSON
          Serial.println("====================================");
          Serial.print(">> 准备上传的 JSON: ");
          //Serial.println(jsonPayload);
          Serial.println("====================================");
          
          // HTTP POST
          SendData(jsonPayload);
          // ==========================================
           
          lastJsonTime = millis(); // 更新时间
      }
      // ==========================================
      
    } else {
      Serial.println("Finger away - Please place steadily");
      validHeartRate = 0;
      validSPO2 = 0;
    }
  }
}

void connectWiFi(){
    // We start by connecting to a WiFi network
    Serial.println();
    Serial.print("Connecting to ");
    Serial.println(ssid);

    WiFi.begin(ssid, password);

    while (WiFi.status() != WL_CONNECTED) {
        delay(500);
        Serial.print(".");
    }

    Serial.println("");
    Serial.println("WiFi connected");
    Serial.println("IP address: ");
    Serial.println(WiFi.localIP());
}

void SendData(String postData){

 if (http.begin(DATA_SERVER_URL)) {
    http.addHeader("Content-Type", "application/json");


    Serial.print("发送数据：");
    Serial.println(postData);

    int httpCode = http.PUT(postData);
    
    if (httpCode > 0) {
      Serial.printf("HTTP 返回码：%d\n", httpCode);
      if (httpCode == HTTP_CODE_OK) {
        String response = http.getString();
        Serial.print("服务器返回：");
        Serial.println(response);
      }
    } else {
      Serial.print("请求失败：");
      Serial.println(http.errorToString(httpCode));
    }

    http.end();
  } else {
    Serial.println("连接服务器失败！");
  }
}