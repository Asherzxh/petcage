#include "ServoMotorfood.h"
#include <Arduino.h>
#include "esp32-hal-ledc.h" 
ServoMotorfood::ServoMotorfood() {
  _currentAngle = 90;
  _isReady = false;
}

bool ServoMotorfood::begin() {
  // SG90 标准 PWM 参数

    ledcSetup(SERVO_CHfood, 50, 10);  // 50Hz, 10bit
  ledcAttachPin(SERVO_PINfood , SERVO_CHfood);
  _isReady = true;
  setAngle(90);  // 上电默认90度
  return true;
  
}

void ServoMotorfood::setAngle(uint8_t angle) {
  if (!_isReady) return;

  if (angle > 180) angle = 180;
  if (angle < 0) angle = 0;

  // SG90 角度 -> PWM 计算
  int pulseWidth = map(angle, 0, 180, 26, 123);
  ledcWrite(SERVO_CHfood, pulseWidth);
  _currentAngle = angle;
}

uint8_t ServoMotorfood::getAngle() {
  return _currentAngle;
}