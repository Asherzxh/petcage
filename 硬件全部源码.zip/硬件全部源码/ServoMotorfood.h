#ifndef SERVO_MOTORFOOD_H
#define SERVO_MOTORFOOD_H

#include <Arduino.h>
#include "Config.h"
class ServoMotorfood {
private:
  uint8_t _currentAngle;
  bool _isReady;


  

public:
  ServoMotorfood();

  // 初始化
  bool begin();

  // 转到角度 0~180
  void setAngle(uint8_t angle);

  // 获取当前角度
  uint8_t getAngle();
};

#endif