#include "WaterPumpDrink.h"

WaterPumpDrink::WaterPumpDrink() {
  _isRunning = false;
}

bool WaterPumpDrink::begin() {
  pinMode(PUMPDRINK_RELAY_PIN , OUTPUT);
  off();  // 默认关闭
  return true;
}

void WaterPumpDrink::on() {
  digitalWrite(PUMPDRINK_RELAY_PIN , RELAY_ON_LEVEL);
  _isRunning = true;
}

void WaterPumpDrink::off() {
  digitalWrite(PUMPDRINK_RELAY_PIN , !RELAY_ON_LEVEL);
  _isRunning = false;
}

bool WaterPumpDrink::isRunning() {
  return _isRunning;
}