#ifndef FAN_CONTROLLER_H
#define FAN_CONTROLLER_H

#include <Arduino.h>
#include "Config.h"

class FanController {
private:
  uint8_t _pwmPin;
  bool _isReady;

public:
  FanController() : _pwmPin(FAN_PWM_PIN), _isReady(false) {}
  
  bool begin();
  void setSpeed(uint8_t speed);
  bool isReady() { return _isReady; }
};

#endif