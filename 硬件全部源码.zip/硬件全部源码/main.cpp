#include <Arduino.h>
#include <Wire.h>
#include <WiFi.h>
#include <ArduinoJson.h>
#include "Config.h"
#include "SHT3X.h"
#include "GasSensorSGP30.h"
#include "FanController.h"
#include "ServoMotor.h"
#include "GravitySensorHX711.h"
#include "WaterPump.h"
#include "Timer0Controller.h"
#include "Timer1Controller.h"
#include "ServoMotorfood.h"
#include "WaterPumpDrink.h"
#include "GravitySensorHX711Drink.h"
#include "HTTPClient.h"

// 全局实例
SHT3X sht3x;
GasSensorSGP30 gasSensor;
FanController fan;
HX711WeightSensor wei;
ServoMotor servo;
ServoMotorfood servo_food;
WaterPump waterPump;
WaterPumpDrink waterPumpDrink;
HX711WeightSensorDrink weidrink;
HTTPClient http;

// 全局变量
 unsigned long fanRunStartTime = 0;
 bool fanIsRunning = false;
 



bool if_pump = false;
bool if_open_door = false;
bool if_open_fan = false;
bool if_pumpdrink = false;
bool if_food = false;

// 函数声明
void judgeFanSpeed(uint16_t eco2, float tem, float hum);
String sensorSamplingTask();
void initI2CBus();
void initSystem();
bool connectWiFi();
bool Judge_Heat(float tem);
bool Judge_food(float weight);
void Heat_On();
void Heat_off();
bool judge_water(float wd);
void SendData(String postData);
void ReceiveCommand();

// ==============================================
void setup() {
  Serial.begin(115200);
  while (!Serial) delay(10);
  Serial.println("===== 系统启动 =====");

  pinMode(HEAT_RELAY_PIN, OUTPUT);
  Heat_off();

  connectWiFi();
  initSystem();
  initTimer1();
  startTimer1();

  servo_food.setAngle(0);
  servo.setAngle(0);
  delay(500);
 
 
}

// ==============================================
void loop() {
  if (WiFi.status() != WL_CONNECTED) {
    Serial.println("WiFi 断开，重连中...");
    delay(1000);
    return;
  }
  
//接受云端开关指令
   ReceiveCommand();



  // 清理水泵
  if ( timer1Flag ||if_pump) {
    if (!waterPump.isRunning()) {
      waterPump.on();
      delay(2000);
      waterPump.off();
      Serial.println("🌀 清粪便水泵启动");
    }
    if_pump = false;
     timer1Flag = false;
  }



  // 饮水水泵
  weidrink.readData();
  float water_weight = weidrink.getWeight();
  if (judge_water(water_weight) || if_pumpdrink) {
    if (!waterPumpDrink.isRunning()) {
      waterPumpDrink.on();
      delay(2000);
       waterPumpDrink.off();
      Serial.println("🌀 饮水水泵启动2秒");
          
    }
if_pumpdrink = false;
    
  }
  if ( water_weight >= Water_LEFT_HIGH) {
    waterPumpDrink.off();
  
    Serial.println("🛑 饮水水泵停止");
  }


  // ====================== 门逻辑（你要的：保持打开直到云端发 false）======================
  if (if_open_door) {
    servo.setAngle(90); 
    delay(100);  // 保持打开
    Serial.println("门打开了");
    if_open_door=false;
    
  } else  {
    servo.setAngle(0);  
    Serial.println("门关闭了");   // 只有云端为 false 才关闭
    if_open_door=false;
  }
  // =====R================= 180° 投喂舵机 ======================
  
  
  wei.readData();
  float weight = wei.getWeight();

  if (if_food|| (Judge_food(weight))  ) {
   
    servo_food.setAngle(0);
     Serial.println("🍽️ 投食开启2s");
    delay(3000);
   servo_food.setAngle(90);
   delay(100);
   Serial.println("✅ 投食已回正");
    if_food = false;
    
  }

  if (weight >= FOOD_LEFT_HIGH) {
    servo_food.setAngle(0);
    if_food=false;
  }
sht3x.readData();
  // 加热逻辑
  static bool heatIsRunning = false;
  if (sht3x.isReady()) {
    float t = sht3x.getTemperature();
    if (Judge_Heat(t) && !heatIsRunning) {
      Heat_On();
      heatIsRunning = true;
      Serial.printf("🔥 加热：%.1f℃\n", t);
    } else if (!Judge_Heat(t) && heatIsRunning) {
      Heat_off();
      heatIsRunning = false;
      Serial.printf("❄️ 停止加热：%.1f℃\n", t);
    }
  }
  //风扇逻辑
  gasSensor.readData();
   judgeFanSpeed(gasSensor.getECO2(), sht3x.getTemperature(), sht3x.getHumidity());
                                       
 String data = sensorSamplingTask();
  SendData(data);

  // 定时上传状态,防止发过状态后正好收到命令


}

// ==============================================
bool connectWiFi() {
  Serial.print("WiFi 连接中...");
  WiFi.begin(WIFI_SSID, WIFI_PASSWORD);
  for (int i = 0; i < 20; i++) {
    if (WiFi.status() == WL_CONNECTED) break;
    delay(500);
    Serial.print(".");
  }
  if (WiFi.status() == WL_CONNECTED) {
    Serial.println("\n✅ WiFi 成功：" + WiFi.localIP().toString());
    return true;
  } else {
    Serial.println("\n❌ WiFi 失败");
    return false;
  }
}

void initI2CBus() {
  Wire.begin(I2C_SDA_PIN, I2C_SCL_PIN);
  Wire.setClock(400000);
}

void initSystem() {
  initI2CBus();
  if (!sht3x.begin()) Serial.println("❌ SHT3X 错误");
  if (!gasSensor.begin()) Serial.println("❌ SGP30 错误");
  if (!fan.begin()) Serial.println("❌ 风扇错误");
  if (!wei.begin()) Serial.println("❌ 称重错误");
  if (!weidrink.begin()) Serial.println("❌ 称重(饮水)错误");
  if (!servo.begin()) Serial.println("❌ 舵机(门)错误");
  if (!servo_food.begin()) Serial.println("❌ 舵机(投食)错误");
  if (!waterPump.begin()) Serial.println("❌ 水泵错误");
  if (!waterPumpDrink.begin()) Serial.println("❌ 水泵(饮水)错误");
  Serial.println("✅ 系统初始化完成");
}

String sensorSamplingTask() {
  gasSensor.readData();
  sht3x.readData();
  wei.readData();
  weidrink.readData();
 

  Serial.printf("📊 eCO2:%d TVOC:%d 温:%.1f℃ 湿:%.1f%% 食物:%.1fg 饮水:%.1fg\n",
    gasSensor.getECO2(), gasSensor.getTVOC(),
    sht3x.getTemperature(), sht3x.getHumidity(),
    wei.getWeight(), weidrink.getWeight());

  JsonDocument jsdoc;
  jsdoc["carbonDioxide"] = gasSensor.getECO2();
  jsdoc["organicGas"] = gasSensor.getTVOC();
  jsdoc["cageTemperature"] = sht3x.getTemperature();
  jsdoc["humidity"] = sht3x.getHumidity();
  jsdoc["water"] = weidrink.getWeight();
  jsdoc["food"] = wei.getWeight();

  String postData;
  serializeJson(jsdoc, postData);
  return postData;
}

void SendData(String postData) {
  if (WiFi.status() != WL_CONNECTED) return;
  if (http.begin(DATA_SERVER_URL)) {
    http.addHeader("Content-Type", "application/json");
    int httpCode = http.PUT(postData);
    
    if (httpCode > 0) Serial.printf("传感器上传：%d\n", httpCode);
    http.end();
  }
  
}



// 接收云端指令（修复版：只触发一次，执行后自动清空）
void ReceiveCommand() {
  if (WiFi.status() != WL_CONNECTED) return;

  http.begin(GET_COMMAND_URL);
  int code = http.GET();
  String res = http.getString();
  http.end();
  Serial.println(res);

  JsonDocument doc;
  DeserializationError err = deserializeJson(doc, res);
  if (err) {
    Serial.print("解析错误：");
    Serial.println(err.c_str());
    return;
  }

  // 【关键】只在云端为 true 时触发一次，不持续覆盖本地状态
  if (doc["data"]["cageDoor"].as<bool>()) {
    if_open_door = true;
  }
  if (doc["data"]["ventilation"].as<bool>()) {
    if_open_fan = true;
  }
  if (doc["data"]["feed"].as<bool>()) {
    if_food = true;
  }
  if (doc["data"]["water"].as<bool>()) {
    if_pumpdrink = true;
  }
  if (doc["data"]["clean"].as<bool>()) {
    if_pump = true;
  }

  Serial.println("📥 指令接收成功（触发模式）");
}

// ====================== 风扇逻辑：不清零 if_open_fan，完全正常！======================
void judgeFanSpeed(uint16_t eco2, float tem, float hum) {
  bool need = (eco2 > ECO2_HIGH_THRESHOLD) ||
              (tem > TEMPERATURE_HIGH_THRESHOLD) ||
              (hum > HUMIDITY_HIGH_THRESHOLD) ||
              if_open_fan;  // 云端强制开启

  if (need &&!fanIsRunning) {
    
    fan.setSpeed(FAN_FULL_SPEED);
    fanIsRunning = true;
  } else {
    fan.setSpeed(FAN_STOP);
    fanIsRunning = false;
       if_open_fan = false; // 自动关闭云端触发的风扇指令
    
  }
}

bool Judge_Heat(float t) { return t < TEMPERATURE_HEAT_THRESHOLD; }
bool Judge_food(float w) { return w < FOOD_LEFT_LOW; }
bool judge_water(float wd) { return wd < WATER_LEFT_LOW; }
void Heat_On() { digitalWrite(HEAT_RELAY_PIN, HIGH); }
void Heat_off() { digitalWrite(HEAT_RELAY_PIN, LOW); }