#ifndef GAS_SENSOR_SGP30_H
#define GAS_SENSOR_SGP30_H

#include <Wire.h>
#include "Adafruit_SGP30.h"
#include "Config.h"

class GasSensorSGP30 {
private:
  Adafruit_SGP30 _sgp;
  uint16_t _eco2;
  uint16_t _tvoc;
  bool _isReady;

public:
  GasSensorSGP30() : _eco2(0), _tvoc(0), _isReady(false) {}
  
  bool begin();
  bool readData();
  
  uint16_t getECO2() { return _eco2; }
  uint16_t getTVOC() { return _tvoc; }
  bool isReady()     { return _isReady; }
};

#endif