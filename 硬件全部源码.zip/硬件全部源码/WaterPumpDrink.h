#ifndef WATER_PUMPDRINK_H
#define WATER_PUMPDRINK_H

#include <Arduino.h>
#include "Config.h"

class WaterPumpDrink {
private:
  bool _isRunning;

public:
  WaterPumpDrink();

  // 初始化
  bool begin();

  // 打开水泵
  void on();

  // 关闭水泵
  void off();

  // 获取状态
  bool isRunning();
};

#endif