#ifndef HX711_WEIGHT_SENSORDRINK_H
#define HX711_WEIGHT_SENSORDRINK_H

#include <Arduino.h>
#include "HX711.h"
#include "Config.h"

class HX711WeightSensorDrink {
private:
  HX711 _hx711;
  float _weight;
  bool _isReady;

public:
  HX711WeightSensorDrink();

  bool begin();
  bool readData();
  float getWeight();
  bool isReady();
};

#endif