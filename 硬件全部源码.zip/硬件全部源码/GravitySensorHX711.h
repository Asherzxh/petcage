#ifndef HX711_WEIGHT_SENSOR_H
#define HX711_WEIGHT_SENSOR_H

#include <Arduino.h>
#include "HX711.h"
#include "Config.h"

class HX711WeightSensor {
private:
  HX711 _hx711;
  float _weight;
  bool _isReady;

public:
  HX711WeightSensor();

  bool begin();
  bool readData();
  float getWeight();
  bool isReady();
};

#endif