#include "GravitySensorHX711Drink.h"
#
HX711WeightSensorDrink::HX711WeightSensorDrink() {
  _weight = 0.0f;
  _isReady = false;
}

// 初始化：完全不去皮
bool HX711WeightSensorDrink::begin() {
  _hx711.begin(HX711DRINK_DT_PIN, HX711DRINK_SCK_PIN);
  delay(2000);
  Serial.println("饮水重量初始化成功");
  _isReady = true;
  return true;
}

// 核心：自动计算真实重量
bool HX711WeightSensorDrink::readData() {
  if (!_isReady) return false;

 
  
  // 稳定读取
  long currentRaw = _hx711.read_average(20);
   
  // 真实重量 = (当前值 - 空盘值) / 校准系数
  _weight = (float)(currentRaw - EMPTYDRINK_RAW) / HX711DRINK_CAL_FACTOR;

  // 空了自动归0，不会出现负数
  if (_weight < 0) _weight = 0;

  return true;
}

float HX711WeightSensorDrink::getWeight() {
  return _weight;
}

bool HX711WeightSensorDrink::isReady() {
  return _isReady;
}