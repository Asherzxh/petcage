#ifndef CONFIG_H
#define CONFIG_H

#include <Arduino.h>


// ==================== 核心引脚配置 ====================
// I2C总线（SHT3X/SGP30共用）
#define I2C_SDA_PIN    15
#define I2C_SCL_PIN    16

// 风扇控制引脚（原18被摄像头占用，改为4引脚）
#define FAN_PWM_PIN    4

// ==================== 舵机 SG90喂食 ====================
#define SERVO_PINfood           6
// ESP32 PWM 通道 (0-15)，不和别人冲突即可
#define SERVO_CHfood            0
// ==================== 舵机 SG90开门 ====================
#define SERVO_PIN         14
#define SERVO_CH           1
// ==================== 加热片 ====================
#define HEAT_RELAY_PIN       5
// ==================== 水泵 5V + 继电器 ====================
#define PUMP_RELAY_PIN      12
#define RELAY_ON_LEVEL      HIGH  // 如果继电器低电平吸合，改为 LOW
// ==================== 水泵 5V喝水 + 继电器 ====================
#define PUMPDRINK_RELAY_PIN      13

// ==================== HX711 食物称重传感器 ====================
#define HX711_DT_PIN        18
#define HX711_SCK_PIN       17
#define HX711_CAL_FACTOR    359.0f  // 校准值
#define EMPTY_RAW           -315030L  // 空盘原始值（统一移到Config）
// ==================== HX711 水称重传感器 ====================
#define HX711DRINK_DT_PIN        8
#define HX711DRINK_SCK_PIN       3
#define HX711DRINK_CAL_FACTOR    359.0f  // 先复用食物的校准系数，后续微调
#define EMPTYDRINK_RAW           355074L // 填入你实测的空盘原始值
//====================定时器0配置====================
extern hw_timer_t *timer0 ;
extern volatile bool timer0Flag; // 定时器0触发传感器采样
#define time0_time 10000000  // 10秒

//====================定时器1配置====================
extern hw_timer_t *timer1 ;
extern volatile bool timer1Flag ;

//  #define time1_time 3600000000 // 10秒（测试用）
#define time1_time 3600000000

// ==================== 阈值配置 ====================
// 气体浓度阈值
#define ECO2_HIGH_THRESHOLD 2000  // 风扇全速
#define ECO2_LOW_THRESHOLD  1000  // 风扇停止
//温度阈值
#define TEMPERATURE_HIGH_THRESHOLD 28.0
#define TEMPERATURE_LOW_THRESHOLD 20.0
#define TEMPERATURE_HEAT_THRESHOLD 20.0 // 加热启动阈值
#define TEMPERATURE_HEAT_STOP_THRESHOLD 25.0 // 加热停止阈值
//湿度阈值
#define HUMIDITY_HIGH_THRESHOLD 65.0
#define HUMIDITY_LOW_THRESHOLD 40.0
// 风扇档位
#define FAN_STOP       0
#define FAN_HALF_SPEED 128
#define FAN_FULL_SPEED 255
//食物余量阈值
#define FOOD_LEFT_LOW 30.0f
#define FOOD_LEFT_HIGH 50.0f
//饮水余量阈值
#define WATER_LEFT_LOW 70.0f
#define Water_LEFT_HIGH 120.0f
// ==================== 定时器配置（预留） ====================
// 传感器采样周期（ms）
#define SENSOR_SAMPLING_INTERVAL 1000
// 未来扩展定时器编号（ESP32定时器0）
#define TIMER_NUM      0
#define TIMER_PRESCALER 80
#define TIMER_INTERVAL_US (SENSOR_SAMPLING_INTERVAL * 1000)

// ==================== 网络配置 ====================
// WiFi配置
//该部分可以改为其他WiFi名和密码
#define WIFI_SSID     ""
#define WIFI_PASSWORD ""
// 云服务器配置（占位符）
#define DATA_SERVER_URL  ""  // 传感器数据上传地址
#define GET_COMMAND_URL ""                                                                    //与后端的访问接口
                                                    
#endif