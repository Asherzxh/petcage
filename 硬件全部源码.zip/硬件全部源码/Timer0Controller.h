#ifndef TIMER0CONTROLLER_H
#define TIMER0CONTROLLER_H


#include <Arduino.h>
#include <Config.h>
void initTimer0();
void startTimer0();
void stopTimer0();
void IRAM_ATTR onTimer0();

#endif
