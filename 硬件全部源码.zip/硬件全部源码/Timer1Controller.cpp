#include "Timer1Controller.h"

hw_timer_t *timer1 = NULL;
volatile bool timer1Flag = false;

void initTimer1() {
  // 分频 80 → 1MHz (1us 计数一次)
  timer1 = timerBegin(1, 80, true);
  
  // 绑定中断
  timerAttachInterrupt(timer1, onTimer1, true);

  // ======================
  // 1 小时 = 3600秒 = 3600000000 微秒 启动一次中断
  // ======================
  timerAlarmWrite(timer1, time1_time, true);//先测试10秒一次水泵
}

void startTimer1() {
  timerAlarmEnable(timer1);
}

void stopTimer1() {
  timerAlarmDisable(timer1);
}
void IRAM_ATTR onTimer1() {

timer1Flag = true;


  
}
