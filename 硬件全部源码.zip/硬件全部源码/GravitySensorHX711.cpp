#include "GravitySensorHX711.h"

HX711WeightSensor::HX711WeightSensor() {
  _weight = 0.0f;
  _isReady = false;
}

// 初始化：完全不去皮
bool HX711WeightSensor::begin() {
  _hx711.begin(HX711_DT_PIN, HX711_SCK_PIN);
  delay(2000);
  _isReady = true;
  return true;
}

// 核心：自动计算真实重量
bool HX711WeightSensor::readData() {
  if (!_isReady) return false;

  // 稳定读取
  long currentRaw = _hx711.read_average(20);
  
  // 真实重量 = (当前值 - 空盘值) / 校准系数
  _weight = (float)(currentRaw - EMPTY_RAW) / HX711_CAL_FACTOR;

  // 空了自动归0，不会出现负数
  if (_weight < 0) _weight = 0;

  return true;
}

float HX711WeightSensor::getWeight() {
  return _weight;
}

bool HX711WeightSensor::isReady() {
  return _isReady;
}