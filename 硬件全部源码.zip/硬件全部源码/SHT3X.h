#ifndef SHT3X_H
#define SHT3X_H

#include <Wire.h>
#include "Adafruit_SHT31.h"
#include "Config.h"

class SHT3X {
private:
  Adafruit_SHT31 _sht;
  float _temperature;
  float _humidity;
  bool _isReady;

public:
  // 构造函数
  SHT3X() : _temperature(0.0f), _humidity(0.0f), _isReady(false) {}
  
  // 初始化传感器（仅初始化传感器，不重复初始化I2C）
  bool begin();
  
  // 读取温湿度数据
  bool readData();
  
  // 获取数据
  float getTemperature() { return _temperature; }
  float getHumidity()    { return _humidity; }
  bool isReady()         { return _isReady; }
};

#endif