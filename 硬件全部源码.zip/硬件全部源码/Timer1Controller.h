#ifndef TIMER1CONTROLLER_H
#define TIMER1CONTROLLER_H

#include <Arduino.h>
#include <Config.h>
void initTimer1();
void startTimer1();
void stopTimer1();
void IRAM_ATTR onTimer1();

#endif