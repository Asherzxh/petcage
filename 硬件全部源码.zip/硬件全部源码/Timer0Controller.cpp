#include "Timer0Controller.h"

hw_timer_t *timer0 = NULL;
volatile bool timer0Flag = false;
static int cnt=0;
void initTimer0() {
  // 分频 80 → 1MHz (1us 计数一次)
  timer0 = timerBegin(0, 80, true);
  
  // 绑定中断
  timerAttachInterrupt(timer0, onTimer0, true);
  //一秒启动一次中断
  timerAlarmWrite(timer0,time0_time,true);
}

void startTimer0() {
  timerAlarmEnable(timer0);
}

void stopTimer0() {
  timerAlarmDisable(timer0);
}

void IRAM_ATTR onTimer0() {

timer0Flag = true;


  
}